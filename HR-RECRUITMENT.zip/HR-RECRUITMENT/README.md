# HR Recruitment (Flask 2)

Interview management: **Admin**, **Recruiter**, and **Candidate** roles; resume upload; scheduling; feedback; status (**pending** / **selected** / **rejected**); email notifications (logged to console if SMTP is not configured).

## Stack (by design)

| Layer | Technology |
|--------|------------|
| Runtime | **Python 3** (3.8+) |
| Web framework | **Flask 2** (see `requirements.txt`) |
| UI | **HTML** templates + **CSS** in `static/css/app.css` only — no Bootstrap CDN, no Tailwind CDN, no React/Vue. SVG logos/hero images are static files under `static/images/`. |
| Database | SQLite (`instance/hr.sqlite3`) via SQLAlchemy |

Server-side packages (Flask-SQLAlchemy, Flask-Login, Flask-Mail, etc.) are listed only in **`requirements.txt`**.

## Prerequisites (personal laptop)

- **Python 3.8+** from [python.org](https://www.python.org/downloads/) — during setup, enable **“Add python.exe to PATH”**.
- Internet access once, to run `pip install`.

## One file: install everything

From the **`HR-RECRUITMENT`** folder, run:

```text
python install.py
```

This creates **`.venv`** (if needed), upgrades **pip**, and installs all packages from **`requirements.txt`**. If your existing **`.venv`** is broken, the script removes it and creates a new one automatically.

Start the app after install:

```text
.venv\Scripts\python.exe app.py
```

Or install and start in one step:

```text
python install.py --run
```

## Other ways to run (Windows)

- **PowerShell:** `.\run_local.ps1` (same idea as `install.py` + `app.py`)
- **Command Prompt:** **`run_local.bat`**

## Manual install (any OS, step by step)

```powershell
cd HR-RECRUITMENT
python -m venv .venv
# Windows PowerShell:
.\.venv\Scripts\Activate.ps1
# Windows CMD:
#   .venv\Scripts\activate.bat
# Linux/macOS:
#   source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000** — login as **Admin** with default **admin** / **admin123** (override with `ADMIN_USERNAME` / `ADMIN_PASSWORD` in a `.env` file).

## Flow

1. **Admin**: add recruiters → add candidates (resume) → assign recruiter → schedule interview → view feedback → set status.
2. **Recruiter**: see assigned candidates → **Give feedback** on each interview.
3. **Candidate**: see schedule and status (same credentials created when admin adds the candidate).

Emails: without `MAIL_SERVER` in `.env`, messages appear in the **terminal log** as `[EMAIL dev log]`.

## Database & uploads

- SQLite file: `instance/hr.sqlite3`
- Resumes: `static/uploads/resumes/`

Copy `.env.example` to `.env` and adjust as needed.

## Cleanup (optional)

To delete **Python cache folders** (`__pycache__`, `.pyc`, test caches) without touching your database, uploads, or `.venv`:

```powershell
.\clean_project.ps1
```

To also remove the **virtual environment** and free disk space (reinstall deps after):

```powershell
.\clean_project.ps1 -RemoveVenv
```

What stays in the repo by design: **application code**, **`requirements.txt`**, **`static/`**, **`templates/`**, **`README`**, **`run_local` scripts**. Local data (`instance/`, uploaded resumes) and `.venv` are listed in `.gitignore` so they are not treated as part of the source tree when using Git.
