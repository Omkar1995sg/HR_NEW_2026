import os

from dotenv import load_dotenv
from flask import Flask, redirect, url_for
from flask_login import current_user
from flask_mail import Mail

from extensions import db, login_manager
from models import User
from schema_migrate import migrate_schema

load_dotenv()


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-me-in-production")
    base = os.path.abspath(os.path.dirname(__file__))
    instance_path = os.path.join(base, "instance")
    os.makedirs(instance_path, exist_ok=True)
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(instance_path, 'hr.sqlite3')}"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    upload_dir = os.path.join(base, "static", "uploads", "resumes")
    os.makedirs(upload_dir, exist_ok=True)
    app.config["UPLOAD_RESUME_FOLDER"] = upload_dir
    app.config["ALLOWED_RESUME_EXTENSIONS"] = {"pdf", "doc", "docx", "txt"}

    # Optional SMTP (leave unset to log emails only)
    app.config["MAIL_SERVER"] = os.environ.get("MAIL_SERVER", "")
    app.config["MAIL_PORT"] = int(os.environ.get("MAIL_PORT", "587"))
    app.config["MAIL_USE_TLS"] = os.environ.get("MAIL_USE_TLS", "true").lower() == "true"
    app.config["MAIL_USERNAME"] = os.environ.get("MAIL_USERNAME", "")
    app.config["MAIL_PASSWORD"] = os.environ.get("MAIL_PASSWORD", "")
    app.config["MAIL_DEFAULT_SENDER"] = os.environ.get("MAIL_DEFAULT_SENDER", "noreply@localhost")

    db.init_app(app)
    login_manager.init_app(app)
    mail = Mail(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    from blueprints import auth as auth_bp
    from blueprints import admin as admin_bp
    from blueprints import recruiter as recruiter_bp
    from blueprints import candidate as candidate_bp
    from blueprints import interviewer as interviewer_bp
    from blueprints import jobs as jobs_bp

    app.register_blueprint(auth_bp.bp)
    app.register_blueprint(admin_bp.bp)
    app.register_blueprint(recruiter_bp.bp)
    app.register_blueprint(candidate_bp.bp)
    app.register_blueprint(interviewer_bp.bp)
    app.register_blueprint(jobs_bp.bp)

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            if current_user.role == "admin":
                return redirect(url_for("admin.dashboard"))
            if current_user.role == "recruiter":
                return redirect(url_for("recruiter.dashboard"))
            if current_user.role == "interviewer":
                return redirect(url_for("interviewer.dashboard"))
            return redirect(url_for("candidate.dashboard"))
        return redirect(url_for("auth.login"))

    with app.app_context():
        migrate_schema()
        _seed_admin(app)

    return app


def _seed_admin(app):
    admin_user = os.environ.get("ADMIN_USERNAME", "admin")
    admin_pass = os.environ.get("ADMIN_PASSWORD", "admin123")
    if User.query.filter_by(role="admin").first():
        return
    u = User(username=admin_user, name="Admin", email=f"{admin_user}@localhost", role="admin")
    u.set_password(admin_pass)
    db.session.add(u)
    db.session.commit()
    app.logger.info("Seeded default admin user '%s' (set ADMIN_USERNAME / ADMIN_PASSWORD in .env)", admin_user)


app = create_app()


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
