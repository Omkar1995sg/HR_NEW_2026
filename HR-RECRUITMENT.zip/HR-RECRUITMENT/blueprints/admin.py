import os
import re
from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user
from sqlalchemy import or_

from decorators import role_required
from email_utils import send_notification_email
from extensions import db
from file_upload import next_job_code, save_resume
from models import Candidate, Evaluation, Interview, Interviewer, JobApplication, JobOpening, User
from pipeline import (
    PIPELINE_COLUMNS,
    PIPELINE_HINTS,
    group_candidates,
    latest_evaluation,
    pipeline_stage,
    suggested_candidate_status,
)

bp = Blueprint("admin", __name__, url_prefix="/admin")


def _after_candidate_action():
    nxt = (request.form.get("next") or request.args.get("next") or "").strip()
    if nxt == "pipeline":
        return url_for("admin.pipeline")
    return url_for("admin.candidates")


def _notify_candidate_status(candidate: Candidate, status: str) -> None:
    label = {"pending": "Pending", "selected": "Selected", "rejected": "Rejected"}[status]
    body = (
        f"Hello {candidate.full_name},\n\n"
        f"Your application status is now: {label}\n\n"
        f"— HR Recruitment System"
    )
    send_notification_email(candidate.user.email, f"Application status: {label}", body)


@bp.route("/")
@bp.route("/dashboard")
@role_required("admin")
def dashboard():
    recruiters = User.query.filter_by(role="recruiter").order_by(User.username).all()
    cand_count = Candidate.query.count()
    interviewer_count = Interviewer.query.count()
    interview_count = Interview.query.count()
    eval_count = Evaluation.query.count()
    pending_decisions = sum(
        1 for c in Candidate.query.filter_by(status="pending").all() if pipeline_stage(c) == "awaiting_decision"
    )
    new_applications = JobApplication.query.filter_by(status="submitted").count()
    open_jobs = JobOpening.query.filter_by(status="open").count()
    return render_template(
        "admin/dashboard.html",
        recruiters=recruiters,
        cand_count=cand_count,
        interviewer_count=interviewer_count,
        interview_count=interview_count,
        eval_count=eval_count,
        pending_decisions=pending_decisions,
        new_applications=new_applications,
        open_jobs=open_jobs,
    )


@bp.route("/pipeline")
@role_required("admin")
def pipeline():
    rows = (
        Candidate.query.order_by(Candidate.created_at.desc()).all()
    )
    buckets = group_candidates(rows)
    pending_decisions = len(buckets.get("awaiting_decision") or [])
    return render_template(
        "admin/pipeline.html",
        columns=PIPELINE_COLUMNS,
        hints=PIPELINE_HINTS,
        buckets=buckets,
        pending_decisions=pending_decisions,
        latest_evaluation=latest_evaluation,
        suggested_candidate_status=suggested_candidate_status,
    )


@bp.route("/recruiters", methods=["GET", "POST"])
@role_required("admin")
def recruiters():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""
        if not username or not email or not password:
            flash("Username, email, and password are required.", "danger")
            return redirect(url_for("admin.recruiters"))
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already exists.", "danger")
            return redirect(url_for("admin.recruiters"))
        u = User(username=username, name=username, email=email, role="recruiter")
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        flash("Recruiter added.", "success")
        return redirect(url_for("admin.recruiters"))

    users = User.query.filter_by(role="recruiter").order_by(User.username).all()
    return render_template("admin/recruiters.html", recruiters=users)


@bp.route("/recruiters/<int:rid>/delete", methods=["POST"])
@role_required("admin")
def delete_recruiter(rid):
    u = User.query.get_or_404(rid)
    if u.role != "recruiter":
        flash("Not a recruiter account.", "danger")
        return redirect(url_for("admin.recruiters"))
    Candidate.query.filter_by(assigned_recruiter_id=u.id).update({"assigned_recruiter_id": None})
    db.session.delete(u)
    db.session.commit()
    flash("Recruiter removed.", "info")
    return redirect(url_for("admin.recruiters"))


@bp.route("/interviewers", methods=["GET", "POST"])
@role_required("admin")
def interviewers():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip()
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        department = (request.form.get("department") or "").strip()
        designation = (request.form.get("designation") or "").strip()
        phone = (request.form.get("phone") or "").strip()
        if not name or not email or not username or not password:
            flash("Name, email, username, and password are required.", "danger")
            return redirect(url_for("admin.interviewers"))
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already exists.", "danger")
            return redirect(url_for("admin.interviewers"))
        u = User(username=username, name=name, email=email, role="interviewer")
        u.set_password(password)
        db.session.add(u)
        db.session.flush()
        iv = Interviewer(
            user_id=u.id,
            admin_id=current_user.id,
            name=name,
            email=email,
            department=department or None,
            designation=designation or None,
            phone=phone or None,
        )
        db.session.add(iv)
        db.session.commit()
        flash("Interviewer added.", "success")
        return redirect(url_for("admin.interviewers"))

    rows = Interviewer.query.order_by(Interviewer.name).all()
    return render_template("admin/interviewers.html", interviewers=rows)


@bp.route("/interviewers/<int:iid>/delete", methods=["POST"])
@role_required("admin")
def delete_interviewer(iid):
    iv = Interviewer.query.get_or_404(iid)
    if Interview.query.filter_by(interviewer_id=iv.id).first():
        flash("Cannot remove an interviewer who already has interviews. Reassign those interviews first.", "danger")
        return redirect(url_for("admin.interviewers"))
    u = iv.user
    db.session.delete(iv)
    if u:
        db.session.delete(u)
    db.session.commit()
    flash("Interviewer removed.", "info")
    return redirect(url_for("admin.interviewers"))


@bp.route("/candidates")
@role_required("admin")
def candidates():
    q = (request.args.get("q") or "").strip()
    query = Candidate.query.join(User, Candidate.user_id == User.id)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Candidate.full_name.ilike(like), User.email.ilike(like)))
    rows = query.order_by(Candidate.created_at.desc()).all()
    recruiters = User.query.filter_by(role="recruiter").order_by(User.username).all()
    return render_template(
        "admin/candidates.html",
        candidates=rows,
        recruiters=recruiters,
        q=q,
    )


@bp.route("/candidates/add", methods=["GET", "POST"])
@role_required("admin")
def add_candidate():
    if request.method == "POST":
        full_name = (request.form.get("full_name") or "").strip()
        email = (request.form.get("email") or "").strip()
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        phone = (request.form.get("phone") or "").strip()
        qualification = (request.form.get("qualification") or "").strip()
        experience = (request.form.get("experience") or "").strip()
        recruiter_id = request.form.get("assigned_recruiter_id") or None
        if recruiter_id:
            recruiter_id = int(recruiter_id)
        f = request.files.get("resume")

        if not full_name or not email or not username or not password:
            flash("Full name, email, username, and password are required.", "danger")
            return redirect(url_for("admin.add_candidate"))
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already exists.", "danger")
            return redirect(url_for("admin.add_candidate"))

        resume_path = save_resume(f) if f and f.filename else None
        if f and f.filename and not resume_path:
            flash("Invalid resume file. Allowed: pdf, doc, docx, txt.", "danger")
            return redirect(url_for("admin.add_candidate"))

        u = User(username=username, name=full_name, email=email, role="candidate")
        u.set_password(password)
        db.session.add(u)
        db.session.flush()

        job_id = request.form.get("job_opening_id") or None
        if job_id:
            job_id = int(job_id)

        c = Candidate(
            user_id=u.id,
            admin_id=current_user.id,
            job_opening_id=job_id,
            full_name=full_name,
            phone=phone or None,
            qualification=qualification or None,
            experience=experience or None,
            resume_path=resume_path,
            status="pending",
            assigned_recruiter_id=recruiter_id,
        )
        db.session.add(c)
        db.session.commit()
        flash("Candidate created.", "success")
        return redirect(url_for("admin.candidates"))

    recruiters = User.query.filter_by(role="recruiter").order_by(User.username).all()
    jobs_open = JobOpening.query.filter_by(status="open").order_by(JobOpening.job_code).all()
    return render_template("admin/candidate_add.html", recruiters=recruiters, jobs_open=jobs_open)


@bp.route("/candidates/<int:cid>/assign", methods=["POST"])
@role_required("admin")
def assign_recruiter(cid):
    c = Candidate.query.get_or_404(cid)
    rid = request.form.get("assigned_recruiter_id")
    if rid in ("", "none", None):
        c.assigned_recruiter_id = None
    else:
        ru = User.query.get_or_404(int(rid))
        if ru.role != "recruiter":
            flash("Invalid recruiter.", "danger")
            return redirect(url_for("admin.candidates"))
        c.assigned_recruiter_id = ru.id
    db.session.commit()
    flash("Recruiter assignment updated.", "success")
    return redirect(_after_candidate_action())


@bp.route("/candidates/<int:cid>/schedule", methods=["GET", "POST"])
@role_required("admin")
def schedule_interview(cid):
    c = Candidate.query.get_or_404(cid)
    interviewers = Interviewer.query.order_by(Interviewer.name).all()
    if request.method == "POST":
        interviewer_id = request.form.get("interviewer_id")
        date_raw = (request.form.get("interview_date") or "").strip()
        time_raw = (request.form.get("interview_time") or "").strip()
        mode = (request.form.get("mode") or "Online").strip()
        status = (request.form.get("status") or "Scheduled").strip()
        location_or_link = (request.form.get("location_or_link") or "").strip()
        notes = (request.form.get("notes") or "").strip()
        if not interviewer_id or not date_raw or not time_raw:
            flash("Interviewer, date, and time are required.", "danger")
            return redirect(url_for("admin.schedule_interview", cid=c.id))
        iv = Interviewer.query.get(int(interviewer_id))
        if not iv:
            flash("Invalid interviewer.", "danger")
            return redirect(url_for("admin.schedule_interview", cid=c.id))
        if mode not in ("Online", "Offline", "Hybrid"):
            mode = "Online"
        if status not in ("Scheduled", "Completed", "Cancelled"):
            status = "Scheduled"
        try:
            when = datetime.fromisoformat(f"{date_raw}T{time_raw}")
        except ValueError:
            flash("Invalid date/time format.", "danger")
            return redirect(url_for("admin.schedule_interview", cid=c.id))

        inv = Interview(
            candidate_id=c.id,
            interviewer_id=iv.id,
            admin_id=current_user.id,
            interview_date=when.date(),
            interview_time=when.time().replace(microsecond=0),
            mode=mode,
            status=status,
            location_or_link=location_or_link or None,
            notes=notes or None,
            created_by_id=current_user.id,
        )
        inv.sync_scheduled_at()
        db.session.add(inv)
        db.session.commit()

        body = (
            f"Hello {c.full_name},\n\n"
            f"Your interview is scheduled for: {when.strftime('%Y-%m-%d %H:%M')}\n"
            f"Mode: {mode}\n"
            f"Interviewer: {iv.name}\n"
        )
        if location_or_link:
            body += f"Location / link: {location_or_link}\n"
        body += "\n— HR Recruitment System"
        send_notification_email(c.user.email, "Interview scheduled", body)
        flash("Interview scheduled and notification sent (check server log if SMTP not configured).", "success")
        return redirect(_after_candidate_action())

    return render_template("admin/schedule.html", candidate=c, interviewers=interviewers)


@bp.route("/candidates/<int:cid>/feedback")
@role_required("admin")
def view_feedback(cid):
    c = Candidate.query.get_or_404(cid)
    interviews = (
        Interview.query.filter_by(candidate_id=c.id).order_by(Interview.scheduled_at.desc()).all()
    )
    return render_template(
        "admin/feedback_view.html",
        candidate=c,
        interviews=interviews,
        latest_eval=latest_evaluation(c),
        suggested=suggested_candidate_status(c),
        stage=pipeline_stage(c),
    )


@bp.route("/candidates/<int:cid>/apply-evaluation", methods=["POST"])
@role_required("admin")
def apply_evaluation(cid):
    c = Candidate.query.get_or_404(cid)
    ev = latest_evaluation(c)
    if not ev:
        flash("No evaluation to apply.", "warning")
        return redirect(_after_candidate_action())
    if ev.result == "Hold":
        flash("Interviewer marked Hold. Candidate stays pending until you select or reject.", "info")
        return redirect(_after_candidate_action())
    status = suggested_candidate_status(c)
    if status not in ("selected", "rejected"):
        flash("Evaluation result is still pending. Ask the interviewer to finish scoring.", "warning")
        return redirect(_after_candidate_action())
    c.status = status
    db.session.commit()
    _notify_candidate_status(c, status)
    flash(
        f"Official status set to {status} from interviewer evaluation (overall {ev.overall_score}/10).",
        "success",
    )
    return redirect(_after_candidate_action())


@bp.route("/candidates/<int:cid>/status", methods=["POST"])
@role_required("admin")
def update_status(cid):
    c = Candidate.query.get_or_404(cid)
    status = (request.form.get("status") or "").strip().lower()
    if status not in ("pending", "selected", "rejected"):
        flash("Invalid status.", "danger")
        return redirect(_after_candidate_action())
    c.status = status
    db.session.commit()
    _notify_candidate_status(c, status)
    flash("Status updated and candidate notified (check server log if SMTP not configured).", "success")
    return redirect(_after_candidate_action())


@bp.route("/jobs", methods=["GET", "POST"])
@role_required("admin")
def jobs():
    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        department = (request.form.get("department") or "").strip()
        location = (request.form.get("location") or "").strip()
        description = (request.form.get("description") or "").strip()
        job_code = (request.form.get("job_code") or "").strip().upper()
        if not title:
            flash("Job title is required.", "danger")
            return redirect(url_for("admin.jobs"))
        if not job_code:
            job_code = next_job_code()
        if JobOpening.query.filter_by(job_code=job_code).first():
            flash("Job ID already exists. Choose another code.", "danger")
            return redirect(url_for("admin.jobs"))
        row = JobOpening(
            job_code=job_code,
            title=title,
            department=department or None,
            location=location or None,
            description=description or None,
            status="open",
            admin_id=current_user.id,
        )
        db.session.add(row)
        db.session.commit()
        flash(f"Job posted with ID {job_code}. Share /jobs/{job_code} for applications.", "success")
        return redirect(url_for("admin.jobs"))

    openings = JobOpening.query.order_by(JobOpening.created_at.desc()).all()
    return render_template("admin/jobs.html", openings=openings, suggested_code=next_job_code())


@bp.route("/jobs/<int:jid>/status", methods=["POST"])
@role_required("admin")
def job_status(jid):
    job = JobOpening.query.get_or_404(jid)
    status = (request.form.get("status") or "").strip().lower()
    if status not in ("open", "closed"):
        flash("Invalid status.", "danger")
        return redirect(url_for("admin.jobs"))
    job.status = status
    db.session.commit()
    flash(f"Job {job.job_code} is now {status}.", "success")
    return redirect(url_for("admin.jobs"))


@bp.route("/applications")
@role_required("admin")
def applications():
    status = (request.args.get("status") or "submitted").strip().lower()
    q = JobApplication.query.join(JobOpening)
    if status != "all":
        q = q.filter(JobApplication.status == status)
    rows = q.order_by(JobApplication.created_at.desc()).all()
    counts = {
        "submitted": JobApplication.query.filter_by(status="submitted").count(),
        "accepted": JobApplication.query.filter_by(status="accepted").count(),
        "rejected": JobApplication.query.filter_by(status="rejected").count(),
    }
    recruiters = User.query.filter_by(role="recruiter").order_by(User.username).all()
    return render_template(
        "admin/applications.html",
        applications=rows,
        filter_status=status,
        counts=counts,
        recruiters=recruiters,
    )


def _username_from_email(email: str) -> str:
    base = re.sub(r"[^a-z0-9]", "", email.split("@")[0].lower())[:20] or "applicant"
    candidate = base
    n = 1
    while User.query.filter_by(username=candidate).first():
        candidate = f"{base}{n}"
        n += 1
    return candidate


@bp.route("/applications/<int:aid>/accept", methods=["POST"])
@role_required("admin")
def accept_application(aid):
    app_row = JobApplication.query.get_or_404(aid)
    if app_row.status != "submitted":
        flash("Application already processed.", "warning")
        return redirect(url_for("admin.applications"))

    if User.query.filter_by(email=app_row.email).first():
        flash("A user with this email already exists. Link manually from Candidates.", "danger")
        return redirect(url_for("admin.applications"))

    temp_pass = os.environ.get("CANDIDATE_DEFAULT_PASSWORD", "changeme123")
    username = _username_from_email(app_row.email)
    u = User(username=username, name=app_row.full_name, email=app_row.email, role="candidate")
    u.set_password(temp_pass)
    db.session.add(u)
    db.session.flush()

    recruiter_id = request.form.get("assigned_recruiter_id")
    rid = int(recruiter_id) if recruiter_id else None

    c = Candidate(
        user_id=u.id,
        admin_id=current_user.id,
        job_opening_id=app_row.job_opening_id,
        full_name=app_row.full_name,
        phone=app_row.phone,
        qualification=app_row.qualification,
        experience=app_row.experience,
        resume_path=app_row.resume_path,
        status="pending",
        assigned_recruiter_id=rid,
    )
    db.session.add(c)
    db.session.flush()
    app_row.status = "accepted"
    app_row.candidate_id = c.id
    db.session.commit()

    body = (
        f"Hello {app_row.full_name},\n\n"
        f"Your application for {app_row.job_opening.job_code} ({app_row.job_opening.title}) was accepted.\n"
        f"Login: username {username}\n"
        f"Use the password HR shared with you.\n\n"
        f"— HR Recruitment System"
    )
    send_notification_email(app_row.email, "Application accepted", body)
    flash(
        f"Accepted application #{aid}. Candidate login: {username} / (default password from .env or changeme123)",
        "success",
    )
    return redirect(url_for("admin.applications"))


@bp.route("/applications/<int:aid>/reject", methods=["POST"])
@role_required("admin")
def reject_application(aid):
    app_row = JobApplication.query.get_or_404(aid)
    if app_row.status != "submitted":
        flash("Application already processed.", "warning")
        return redirect(url_for("admin.applications"))
    app_row.status = "rejected"
    db.session.commit()
    send_notification_email(
        app_row.email,
        f"Application update — {app_row.job_opening.job_code}",
        f"Hello {app_row.full_name},\n\nThank you for applying. We will not be moving forward at this time.\n\n— HR",
    )
    flash("Application rejected.", "info")
    return redirect(url_for("admin.applications"))
