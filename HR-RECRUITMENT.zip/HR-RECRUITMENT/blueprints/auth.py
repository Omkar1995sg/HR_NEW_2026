from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_user, logout_user

from extensions import db
from models import User

bp = Blueprint("auth", __name__)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        role = (request.form.get("role") or "").strip()

        user = User.query.filter_by(username=username).first()
        if not user or not user.check_password(password):
            flash("Invalid username or password.", "danger")
            return render_template("login.html")

        if user.role != role:
            flash("Selected role does not match this account.", "danger")
            return render_template("login.html")

        login_user(user, remember=True)
        flash("Logged in successfully.", "success")
        if user.role == "admin":
            return redirect(url_for("admin.dashboard"))
        if user.role == "recruiter":
            return redirect(url_for("recruiter.dashboard"))
        if user.role == "interviewer":
            return redirect(url_for("interviewer.dashboard"))
        return redirect(url_for("candidate.dashboard"))

    return render_template("login.html")


@bp.route("/logout")
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))
