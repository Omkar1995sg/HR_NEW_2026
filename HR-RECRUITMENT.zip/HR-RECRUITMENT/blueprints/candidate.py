from flask import Blueprint, render_template
from flask_login import current_user

from decorators import role_required
from models import Candidate, Interview

bp = Blueprint("candidate", __name__, url_prefix="/candidate")


@bp.route("/")
@bp.route("/dashboard")
@role_required("candidate")
def dashboard():
    c = Candidate.query.filter_by(user_id=current_user.id).first_or_404()
    interviews = (
        Interview.query.filter_by(candidate_id=c.id).order_by(Interview.scheduled_at.asc()).all()
    )
    return render_template(
        "candidate/dashboard.html",
        candidate=c,
        interviews=interviews,
    )


@bp.route("/result")
@role_required("candidate")
def result():
    c = Candidate.query.filter_by(user_id=current_user.id).first_or_404()
    return render_template("candidate/result.html", candidate=c)
