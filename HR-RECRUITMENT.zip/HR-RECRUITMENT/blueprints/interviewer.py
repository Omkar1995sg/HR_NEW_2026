from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user

from decorators import role_required
from extensions import db
from models import Evaluation, Interview, Interviewer

bp = Blueprint("interviewer", __name__, url_prefix="/interviewer")


def _profile():
    return Interviewer.query.filter_by(user_id=current_user.id).first_or_404()


@bp.route("/")
@bp.route("/dashboard")
@role_required("interviewer")
def dashboard():
    iv = _profile()
    interviews = (
        Interview.query.filter_by(interviewer_id=iv.id)
        .order_by(Interview.scheduled_at.desc())
        .all()
    )
    return render_template("interviewer/dashboard.html", interviewer=iv, interviews=interviews)


@bp.route("/interview/<int:iid>/evaluate", methods=["GET", "POST"])
@role_required("interviewer")
def evaluate(iid):
    iv = _profile()
    inv = Interview.query.get_or_404(iid)
    if inv.interviewer_id != iv.id:
        flash("This interview is not assigned to you.", "danger")
        return redirect(url_for("interviewer.dashboard"))

    existing = Evaluation.query.filter_by(interview_id=inv.id).first()
    if request.method == "POST":
        try:
            technical = int(request.form.get("technical_score"))
            communication = int(request.form.get("communication_score"))
        except (TypeError, ValueError):
            flash("Scores must be numbers from 0 to 10.", "danger")
            return redirect(url_for("interviewer.evaluate", iid=inv.id))
        if not (0 <= technical <= 10 and 0 <= communication <= 10):
            flash("Each score must be between 0 and 10.", "danger")
            return redirect(url_for("interviewer.evaluate", iid=inv.id))
        overall = int(round((technical + communication) / 2))
        result = (request.form.get("result") or "Pending").strip()
        if result not in ("Selected", "Rejected", "Hold", "Pending"):
            result = "Pending"
        comments = (request.form.get("feedback") or "").strip()

        if existing:
            existing.technical_score = technical
            existing.communication_score = communication
            existing.overall_score = overall
            existing.result = result
            existing.feedback = comments
            existing.interviewer_id = iv.id
        else:
            existing = Evaluation(
                interview_id=inv.id,
                interviewer_id=iv.id,
                technical_score=technical,
                communication_score=communication,
                overall_score=overall,
                result=result,
                feedback=comments,
            )
            db.session.add(existing)
        inv.status = "Completed"
        db.session.commit()
        if result in ("Selected", "Rejected", "Hold"):
            flash("Evaluation saved. Admin must confirm before the candidate’s official status changes.", "success")
        else:
            flash("Evaluation saved.", "success")
        return redirect(url_for("interviewer.dashboard"))

    return render_template(
        "interviewer/evaluate.html",
        interview=inv,
        candidate=inv.candidate,
        evaluation=existing,
    )
