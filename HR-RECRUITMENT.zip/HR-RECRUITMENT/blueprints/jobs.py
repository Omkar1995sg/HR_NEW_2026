from flask import Blueprint, flash, redirect, render_template, request, url_for

from extensions import db
from file_upload import save_resume
from models import JobApplication, JobOpening

bp = Blueprint("jobs", __name__)


@bp.route("/jobs")
def list_open():
    openings = (
        JobOpening.query.filter_by(status="open")
        .order_by(JobOpening.created_at.desc())
        .all()
    )
    return render_template("jobs/list.html", openings=openings)


@bp.route("/jobs/<job_code>")
def detail(job_code):
    job = JobOpening.query.filter_by(job_code=job_code.upper()).first_or_404()
    if job.status != "open":
        flash("This position is no longer accepting applications.", "warning")
    return render_template("jobs/detail.html", job=job)


@bp.route("/jobs/<job_code>/apply", methods=["GET", "POST"])
def apply(job_code):
    job = JobOpening.query.filter_by(job_code=job_code.upper()).first_or_404()
    if job.status != "open":
        flash("This job is closed.", "danger")
        return redirect(url_for("jobs.list_open"))

    if request.method == "POST":
        full_name = (request.form.get("full_name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        phone = (request.form.get("phone") or "").strip()
        qualification = (request.form.get("qualification") or "").strip()
        experience = (request.form.get("experience") or "").strip()
        cover_note = (request.form.get("cover_note") or "").strip()
        f = request.files.get("resume")

        if not full_name or not email:
            flash("Name and email are required.", "danger")
            return redirect(url_for("jobs.apply", job_code=job.job_code))

        resume_path = save_resume(f) if f and f.filename else None
        if f and f.filename and not resume_path:
            flash("Invalid resume. Allowed: pdf, doc, docx, txt.", "danger")
            return redirect(url_for("jobs.apply", job_code=job.job_code))

        dup = JobApplication.query.filter_by(
            job_opening_id=job.id, email=email, status="submitted"
        ).first()
        if dup:
            flash("You already submitted an application for this job ID. Admin will review it.", "info")
            return redirect(url_for("jobs.detail", job_code=job.job_code))

        app_row = JobApplication(
            job_opening_id=job.id,
            full_name=full_name,
            email=email,
            phone=phone or None,
            qualification=qualification or None,
            experience=experience or None,
            cover_note=cover_note or None,
            resume_path=resume_path,
            status="submitted",
        )
        db.session.add(app_row)
        db.session.commit()
        flash(
            f"Application submitted for {job.job_code}. Reference #{app_row.id}. HR will contact you.",
            "success",
        )
        return redirect(url_for("jobs.detail", job_code=job.job_code))

    return render_template("jobs/apply.html", job=job)
