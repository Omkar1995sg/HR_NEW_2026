from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import current_user

from decorators import role_required
from pipeline import pipeline_stage
from models import Candidate, Interview

bp = Blueprint("recruiter", __name__, url_prefix="/recruiter")


@bp.route("/")
@bp.route("/dashboard")
@role_required("recruiter")
def dashboard():
    assigned = (
        Candidate.query.filter_by(assigned_recruiter_id=current_user.id)
        .order_by(Candidate.created_at.desc())
        .all()
    )
    interviews_by_cid = {}
    for c in assigned:
        interviews_by_cid[c.id] = (
            Interview.query.filter_by(candidate_id=c.id).order_by(Interview.scheduled_at.desc()).all()
        )
    return render_template(
        "recruiter/dashboard.html",
        candidates=assigned,
        interviews_by_cid=interviews_by_cid,
        pipeline_stage=pipeline_stage,
    )
