# Remove safe junk: __pycache__, *.pyc, pytest caches — never touches .venv, instance DB, or uploads.
# Usage: .\clean_project.ps1
# Optional: .\clean_project.ps1 -RemoveVenv   (deletes .venv; reinstall with pip install -r requirements.txt)

param([switch]$RemoveVenv)

$ErrorActionPreference = "Continue"
$root = $PSScriptRoot
Set-Location $root

Write-Host "Cleaning Python caches under: $root" -ForegroundColor Cyan
$n = 0
Get-ChildItem -Path $root -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch '[\\/]\.venv[\\/]' } |
  ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue; $script:n++ }
Write-Host "  Removed __pycache__ folders: $n" -ForegroundColor Gray

$n = 0
Get-ChildItem -Path $root -Recurse -File -Filter "*.pyc" -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch '[\\/]\.venv[\\/]' } |
  ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue; $script:n++ }
Write-Host "  Removed .pyc files: $n" -ForegroundColor Gray

foreach ($d in @(".pytest_cache", ".mypy_cache", ".ruff_cache", "htmlcov")) {
  $p = Join-Path $root $d
  if (Test-Path $p) {
    Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  Removed $d" -ForegroundColor Gray
  }
}

if ($RemoveVenv) {
  $vp = Join-Path $root ".venv"
  if (Test-Path $vp) {
    Write-Host "Removing .venv (recreate: python -m venv .venv; pip install -r requirements.txt)" -ForegroundColor Yellow
    Remove-Item -LiteralPath $vp -Recurse -Force
  }
}

Write-Host "Done. Kept: instance\, static\uploads\, .env (if present), .venv (unless -RemoveVenv)." -ForegroundColor Green
