from flask import current_app
from flask_mail import Message


def send_notification_email(to_email: str, subject: str, body: str) -> None:
    """
    Sends email if MAIL_SERVER is set; otherwise logs to console (local testing).
    Set MAIL_SERVER, MAIL_USERNAME, MAIL_PASSWORD in .env for real SMTP.
    """
    cfg = current_app.config
    if not (cfg.get("MAIL_SERVER") or "").strip():
        current_app.logger.info("[EMAIL dev log] To: %s | %s\n%s", to_email, subject, body)
        return

    mail = current_app.extensions.get("mail")
    if mail is None:
        current_app.logger.info("[EMAIL fallback — no Mail ext] To: %s | %s\n%s", to_email, subject, body)
        return
    msg = Message(subject=subject, recipients=[to_email], body=body)
    try:
        mail.send(msg)
        current_app.logger.info("Email sent to %s: %s", to_email, subject)
    except Exception as exc:  # noqa: BLE001
        current_app.logger.exception("Failed to send email to %s: %s", to_email, exc)
        current_app.logger.info("[EMAIL fallback log] To: %s | %s\n%s", to_email, subject, body)
