import os
from datetime import datetime
from typing import Optional

from flask import current_app
from werkzeug.utils import secure_filename


def allowed_resume(filename: str) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_RESUME_EXTENSIONS"]


def save_resume(file_storage) -> Optional[str]:
    if not file_storage or not file_storage.filename:
        return None
    if not allowed_resume(file_storage.filename):
        return None
    name = secure_filename(file_storage.filename)
    upload_dir = current_app.config["UPLOAD_RESUME_FOLDER"]
    os.makedirs(upload_dir, exist_ok=True)
    unique = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{name}"
    path_abs = os.path.join(upload_dir, unique)
    file_storage.save(path_abs)
    return f"uploads/resumes/{unique}".replace("\\", "/")


def next_job_code() -> str:
    from models import JobOpening

    last = JobOpening.query.order_by(JobOpening.id.desc()).first()
    seq = (last.id + 1) if last else 1
    return f"HR-JOB-{seq:04d}"
