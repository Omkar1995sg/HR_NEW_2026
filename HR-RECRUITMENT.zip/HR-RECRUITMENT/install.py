#!/usr/bin/env python3
"""
One-shot installer for HR Recruitment.
Requires: Python 3.8+ on PATH.

Usage (from this folder):
  python install.py
  python install.py --run    # install, then start the Flask app
"""
import argparse
import os
import platform
import shutil
import subprocess
import sys
from typing import List

ROOT = os.path.dirname(os.path.abspath(__file__))
VENV_DIR = os.path.join(ROOT, ".venv")
REQ = os.path.join(ROOT, "requirements.txt")


def _py() -> str:
    return sys.executable


def _venv_python() -> str:
    if platform.system() == "Windows":
        return os.path.join(VENV_DIR, "Scripts", "python.exe")
    return os.path.join(VENV_DIR, "bin", "python")


def run(cmd: List[str]) -> None:
    print("+", " ".join(cmd))
    subprocess.check_call(cmd, cwd=ROOT)


def create_fresh_venv() -> None:
    if os.path.isdir(VENV_DIR):
        print("Removing broken or old .venv …")
        shutil.rmtree(VENV_DIR, ignore_errors=True)
    print("Creating virtual environment:", VENV_DIR)
    run([_py(), "-m", "venv", VENV_DIR])


def pip_install(py: str, args: List[str]) -> None:
    run([py, "-m", "pip", "install"] + args)


def venv_python_works(py: str) -> bool:
    """False when python.exe exists but home interpreter was uninstalled (common on Windows)."""
    if not os.path.isfile(py):
        return False
    try:
        subprocess.check_call(
            [py, "-c", "import sys"],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except (subprocess.CalledProcessError, OSError):
        return False


def main() -> None:
    parser = argparse.ArgumentParser(description="Install HR Recruitment dependencies into .venv")
    parser.add_argument(
        "--run",
        action="store_true",
        help="After install, start the app (python app.py in the venv)",
    )
    args = parser.parse_args()

    if not os.path.isfile(REQ):
        print("Missing requirements.txt next to install.py.", file=sys.stderr)
        sys.exit(1)

    if not os.path.isdir(VENV_DIR):
        create_fresh_venv()
    else:
        print("Using existing virtual environment:", VENV_DIR)

    py = _venv_python()
    if not venv_python_works(py):
        print("venv Python is missing or broken (home interpreter uninstalled) — recreating venv.")
        create_fresh_venv()
        py = _venv_python()
        if not venv_python_works(py):
            print("Failed to create a working .venv. Install Python 3.8+ and retry.", file=sys.stderr)
            sys.exit(1)

    def do_pip_install() -> None:
        pip_install(py, ["--upgrade", "pip"])
        pip_install(py, ["-r", REQ])

    try:
        do_pip_install()
    except subprocess.CalledProcessError:
        print("\n pip failed (broken .venv is common). Recreating virtual environment…\n", file=sys.stderr)
        create_fresh_venv()
        py = _venv_python()
        do_pip_install()

    print()
    print("Done. Dependencies are installed in .venv")
    print("  Start app:  ", repr(py), "app.py")
    print("  Or activate: ", "Scripts\\activate" if platform.system() == "Windows" else "source .venv/bin/activate")

    if args.run:
        print()
        print("Starting app…")
        run([py, os.path.join(ROOT, "app.py")])


if __name__ == "__main__":
    main()
