from datetime import datetime

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db


class User(UserMixin, db.Model):
    """Login accounts. Admin/recruiter map to ER 'ADMIN (Recruiter)'."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(200))
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, index=True)

    candidate_profile = db.relationship(
        "Candidate",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
        foreign_keys="Candidate.user_id",
    )
    interviewer_profile = db.relationship(
        "Interviewer",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
        foreign_keys="Interviewer.user_id",
    )

    def display_name(self) -> str:
        return (self.name or self.username or "").strip()

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Candidate(db.Model):
    __tablename__ = "candidates"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    assigned_recruiter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    full_name = db.Column(db.String(200), nullable=False, index=True)
    phone = db.Column(db.String(40))
    qualification = db.Column(db.String(200))
    experience = db.Column(db.String(200))
    resume_path = db.Column(db.String(500))
    job_opening_id = db.Column(db.Integer, db.ForeignKey("job_openings.id"), nullable=True, index=True)
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="candidate_profile", foreign_keys=[user_id])
    managed_by = db.relationship("User", foreign_keys=[admin_id])
    recruiter = db.relationship("User", foreign_keys=[assigned_recruiter_id])
    job_opening = db.relationship("JobOpening", back_populates="candidates")
    interviews = db.relationship("Interview", back_populates="candidate", cascade="all, delete-orphan")


class JobOpening(db.Model):
    __tablename__ = "job_openings"

    id = db.Column(db.Integer, primary_key=True)
    job_code = db.Column(db.String(32), unique=True, nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    department = db.Column(db.String(120))
    location = db.Column(db.String(120))
    description = db.Column(db.Text)
    status = db.Column(db.String(20), nullable=False, default="open", index=True)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    created_by = db.relationship("User", foreign_keys=[admin_id])
    applications = db.relationship("JobApplication", back_populates="job_opening", cascade="all, delete-orphan")
    candidates = db.relationship("Candidate", back_populates="job_opening")


class JobApplication(db.Model):
    __tablename__ = "job_applications"

    id = db.Column(db.Integer, primary_key=True)
    job_opening_id = db.Column(db.Integer, db.ForeignKey("job_openings.id"), nullable=False, index=True)
    full_name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), nullable=False, index=True)
    phone = db.Column(db.String(40))
    qualification = db.Column(db.String(200))
    experience = db.Column(db.String(200))
    cover_note = db.Column(db.Text)
    resume_path = db.Column(db.String(500))
    status = db.Column(db.String(20), nullable=False, default="submitted", index=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    job_opening = db.relationship("JobOpening", back_populates="applications")
    candidate = db.relationship("Candidate", foreign_keys=[candidate_id])


class Interviewer(db.Model):
    __tablename__ = "interviewers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    name = db.Column(db.String(200), nullable=False, index=True)
    email = db.Column(db.String(120), nullable=False)
    department = db.Column(db.String(120))
    designation = db.Column(db.String(120))
    phone = db.Column(db.String(40))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="interviewer_profile", foreign_keys=[user_id])
    managed_by = db.relationship("User", foreign_keys=[admin_id])
    interviews = db.relationship("Interview", back_populates="interviewer")
    evaluations = db.relationship("Evaluation", back_populates="interviewer")


class Interview(db.Model):
    __tablename__ = "interviews"

    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.id"), nullable=False, index=True)
    interviewer_id = db.Column(db.Integer, db.ForeignKey("interviewers.id"), nullable=True, index=True)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    interview_date = db.Column(db.Date, nullable=True, index=True)
    interview_time = db.Column(db.Time, nullable=True)
    mode = db.Column(db.String(40), nullable=False, default="Online")
    status = db.Column(db.String(40), nullable=False, default="Scheduled", index=True)
    location_or_link = db.Column(db.String(500))
    notes = db.Column(db.Text)
    scheduled_at = db.Column(db.DateTime, nullable=True, index=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    candidate = db.relationship("Candidate", back_populates="interviews")
    interviewer = db.relationship("Interviewer", back_populates="interviews")
    managed_by = db.relationship("User", foreign_keys=[admin_id])
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    evaluation = db.relationship(
        "Evaluation",
        back_populates="interview",
        uselist=False,
        cascade="all, delete-orphan",
    )

    def when(self) -> datetime:
        if self.interview_date and self.interview_time:
            return datetime.combine(self.interview_date, self.interview_time)
        if self.scheduled_at:
            return self.scheduled_at
        return datetime.utcnow()

    def sync_scheduled_at(self) -> None:
        if self.interview_date and self.interview_time:
            self.scheduled_at = datetime.combine(self.interview_date, self.interview_time)


class Evaluation(db.Model):
    __tablename__ = "evaluations"
    __table_args__ = (db.UniqueConstraint("interview_id", name="uq_one_evaluation_per_interview"),)

    id = db.Column(db.Integer, primary_key=True)
    interview_id = db.Column(db.Integer, db.ForeignKey("interviews.id"), nullable=False, index=True)
    interviewer_id = db.Column(db.Integer, db.ForeignKey("interviewers.id"), nullable=False, index=True)
    technical_score = db.Column(db.Integer, nullable=False)
    communication_score = db.Column(db.Integer, nullable=False)
    overall_score = db.Column(db.Integer, nullable=False)
    result = db.Column(db.String(40), nullable=False, default="Pending")
    feedback = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    interview = db.relationship("Interview", back_populates="evaluation")
    interviewer = db.relationship("Interviewer", back_populates="evaluations")


# Kept for one-time copy from older databases.
class Feedback(db.Model):
    __tablename__ = "feedbacks"

    id = db.Column(db.Integer, primary_key=True)
    interview_id = db.Column(db.Integer, db.ForeignKey("interviews.id"), nullable=False, index=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.id"), nullable=False, index=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comments = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
