"""Hiring pipeline stages derived from ERD: Candidate → Interview → Evaluation → Admin decision."""

from datetime import datetime

from models import Candidate

EVAL_TO_CANDIDATE_STATUS = {
    "Selected": "selected",
    "Rejected": "rejected",
}

PIPELINE_COLUMNS = (
    ("intake", "Intake"),
    ("interview", "Interview scheduled"),
    ("awaiting_eval", "Awaiting evaluation"),
    ("awaiting_decision", "Awaiting admin decision"),
    ("hired", "Selected"),
    ("rejected", "Rejected"),
)

PIPELINE_HINTS = {
    "intake": "Candidate added; schedule an interview.",
    "interview": "Interview booked; interviewer has not submitted scores yet.",
    "awaiting_eval": "Interview done or in progress; evaluation result still pending.",
    "awaiting_decision": "Interviewer submitted a result. Admin must confirm before the candidate sees it as official.",
    "hired": "Admin confirmed selected.",
    "rejected": "Admin confirmed rejected.",
}


def active_interviews(candidate: Candidate):
    return [inv for inv in (candidate.interviews or []) if (inv.status or "") != "Cancelled"]


def latest_evaluation(candidate: Candidate):
    scored = [inv.evaluation for inv in (candidate.interviews or []) if inv.evaluation]
    if not scored:
        return None
    return max(scored, key=lambda ev: (ev.created_at or datetime.min, ev.id or 0))


def suggested_candidate_status(candidate: Candidate):
    ev = latest_evaluation(candidate)
    if not ev:
        return None
    return EVAL_TO_CANDIDATE_STATUS.get(ev.result)


def pipeline_stage(candidate: Candidate) -> str:
    official = (candidate.status or "pending").lower()
    if official == "selected":
        return "hired"
    if official == "rejected":
        return "rejected"

    ev = latest_evaluation(candidate)
    if ev and ev.result in ("Selected", "Rejected", "Hold"):
        return "awaiting_decision"

    invs = active_interviews(candidate)
    if not invs:
        return "intake"
    if any(inv.evaluation is None for inv in invs):
        return "interview"
    return "awaiting_eval"


def group_candidates(candidates):
    buckets = {key: [] for key, _ in PIPELINE_COLUMNS}
    for c in candidates:
        stage = pipeline_stage(c)
        buckets.setdefault(stage, []).append(c)
    return buckets
