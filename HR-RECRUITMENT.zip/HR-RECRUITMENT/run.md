# HR Management — Install and Run on Any Laptop

## Requirements

- Windows 10/11, macOS, or Linux
- Python 3.8 or newer
- Internet access during the first dependency installation

No separate database, Node.js, npm, Java, or web server is required. The application uses SQLite and creates its database automatically.

## 1. Copy the project

Copy the complete `HR-RECRUITMENT` folder to the laptop. Do not copy an existing `.venv` folder between laptops because virtual environments are machine-specific.

Open PowerShell, Command Prompt, Terminal, or a code editor terminal in the project folder.

## 2. Confirm Python

Windows:

```powershell
python --version
```

macOS/Linux:

```bash
python3 --version
```

If Python is missing, install Python 3.8+ from <https://www.python.org/downloads/>. On Windows, select **Add python.exe to PATH** during installation.

## 3. Configure the application

The application runs with defaults, but creating `.env` is recommended.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Windows Command Prompt:

```bat
copy .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

Edit `.env` and change at least:

```dotenv
SECRET_KEY=replace-with-a-long-random-value
ADMIN_USERNAME=admin
ADMIN_PASSWORD=replace-with-a-secure-password
```

The admin account is created only when the database is first initialized. Changing these values later does not change an existing admin account.

## 4. Install and run

The portable installer works on Windows, macOS, and Linux. It creates `.venv`, upgrades pip, installs every package from `requirements.txt`, and starts the application:

Windows:

```powershell
python install.py --run
```

macOS/Linux:

```bash
python3 install.py --run
```

Open <http://127.0.0.1:5000> in a browser.

To stop the application, return to the terminal and press `Ctrl+C`.

## Later starts

After the first installation, start without reinstalling dependencies.

Windows PowerShell or Command Prompt:

```powershell
.\.venv\Scripts\python.exe app.py
```

macOS/Linux:

```bash
./.venv/bin/python app.py
```

Windows users may instead double-click `run_local.bat` or run:

```powershell
.\run_local.ps1
```

## Data locations

- SQLite database: `instance/hr.sqlite3`
- Uploaded resumes: `static/uploads/resumes/`
- Configuration: `.env`

Back up those items to preserve local records and uploaded resumes. Do not share `.env` because it may contain passwords or email credentials.

## Optional email setup

Without SMTP settings, email messages are printed in the terminal. To send real email, configure these values in `.env`:

```dotenv
MAIL_SERVER=smtp.example.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-account
MAIL_PASSWORD=your-password
MAIL_DEFAULT_SENDER=noreply@example.com
```

## Troubleshooting

### `python` is not recognized

Install Python and enable **Add Python to PATH**, then close and reopen the terminal. On macOS/Linux, use `python3`.

### PowerShell blocks script execution

Use the portable installer instead:

```powershell
python install.py --run
```

### Broken or copied virtual environment

Delete `.venv`, then recreate it:

Windows PowerShell:

```powershell
Remove-Item -Recurse -Force .venv
python install.py --run
```

macOS/Linux:

```bash
rm -rf .venv
python3 install.py --run
```

### Port 5000 is already in use

Stop the other application using port 5000, or change the port in the final `app.run(...)` call in `app.py`.

### Reset all local application data

Stop the application and delete `instance/hr.sqlite3`. The next start creates a new empty database and admin account. This permanently removes existing local records, so back it up first.
