@echo off
setlocal
cd /d "%~dp0"

echo === HR Recruitment - setup ===

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Install Python 3.8+ from https://www.python.org/ and add it to PATH.
  pause
  exit /b 1
)

python --version

if not exist ".venv" (
  echo Creating virtual environment .venv ...
  python -m venv .venv
)

".venv\Scripts\python.exe" -c "import sys" >nul 2>&1
if errorlevel 1 (
  echo Existing .venv is broken. Recreating...
  rmdir /s /q ".venv"
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip -q
pip install -r requirements.txt

echo.
echo === Starting server at http://127.0.0.1:5000 ===
echo Press Ctrl+C to stop.
echo.

python app.py
pause
