# HR Recruitment — one-shot setup + run (Windows PowerShell)
# Usage: right-click → Run with PowerShell, OR:  .\run_local.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "=== HR Recruitment — setup ===" -ForegroundColor Cyan

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python not found. Install Python 3.8+ from https://www.python.org/downloads/ and check 'Add python.exe to PATH'." -ForegroundColor Red
    exit 1
}

python --version

if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment .venv ..." -ForegroundColor Yellow
    python -m venv .venv
}

$pip = Join-Path $PSScriptRoot ".venv\Scripts\pip.exe"
$py  = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

& $py -c "import sys" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Existing .venv is broken (Python home missing). Recreating..." -ForegroundColor Yellow
    Remove-Item -Recurse -Force ".venv"
    python -m venv .venv
    $pip = Join-Path $PSScriptRoot ".venv\Scripts\pip.exe"
    $py  = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
}

Write-Host "Upgrading pip ..." -ForegroundColor Yellow
& $pip install --upgrade pip -q

Write-Host "Installing dependencies from requirements.txt ..." -ForegroundColor Yellow
& $pip install -r requirements.txt

Write-Host "`n=== Starting server at http://127.0.0.1:5000 ===" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop.`n" -ForegroundColor Gray

& $py app.py
