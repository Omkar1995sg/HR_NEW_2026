"""Bring an existing SQLite file in line with the ER diagram without dropping data."""

from datetime import datetime

from sqlalchemy import inspect, text

from extensions import db
from models import Evaluation, Feedback, Interview, Interviewer, User


def _table_exists(name: str) -> bool:
    return inspect(db.engine).has_table(name)


def _columns(table: str) -> set:
    if not _table_exists(table):
        return set()
    return {row[1] for row in db.session.execute(text(f"PRAGMA table_info({table})"))}


def _add_column(table: str, col: str, ddl: str) -> None:
    if col not in _columns(table):
        db.session.execute(text(f"ALTER TABLE {table} ADD COLUMN {ddl}"))


def migrate_schema() -> None:
    db.create_all()

    _add_column("users", "name", "name VARCHAR(200)")
    _add_column("candidates", "admin_id", "admin_id INTEGER")
    _add_column("candidates", "qualification", "qualification VARCHAR(200)")
    _add_column("candidates", "experience", "experience VARCHAR(200)")
    _add_column("candidates", "job_opening_id", "job_opening_id INTEGER")
    _add_column("interviews", "interviewer_id", "interviewer_id INTEGER")
    _add_column("interviews", "admin_id", "admin_id INTEGER")
    _add_column("interviews", "interview_date", "interview_date DATE")
    _add_column("interviews", "interview_time", "interview_time TIME")
    _add_column("interviews", "mode", "mode VARCHAR(40) DEFAULT 'Online'")
    _add_column("interviews", "status", "status VARCHAR(40) DEFAULT 'Scheduled'")
    db.session.commit()

    admin = User.query.filter_by(role="admin").first()
    if admin:
        db.session.execute(
            text("UPDATE candidates SET admin_id = :aid WHERE admin_id IS NULL"),
            {"aid": admin.id},
        )
        db.session.execute(
            text("UPDATE interviews SET admin_id = COALESCE(admin_id, created_by_id, :aid)"),
            {"aid": admin.id},
        )
        db.session.commit()

    for inv in Interview.query.all():
        if inv.scheduled_at and (inv.interview_date is None or inv.interview_time is None):
            inv.interview_date = inv.scheduled_at.date()
            inv.interview_time = inv.scheduled_at.time().replace(microsecond=0)
        if not inv.mode:
            inv.mode = "Online"
        if not inv.status:
            inv.status = "Scheduled"
        inv.sync_scheduled_at()
    db.session.commit()

    if not _table_exists("feedbacks"):
        return
    if Evaluation.query.count() > 0:
        return
    if Feedback.query.count() == 0:
        return

    first_iv = Interviewer.query.first()
    for fb in Feedback.query.all():
        inv = db.session.get(Interview, fb.interview_id)
        if not inv:
            continue
        interviewer = inv.interviewer or first_iv
        if not interviewer:
            continue
        if Evaluation.query.filter_by(interview_id=inv.id).first():
            continue
        overall = max(0, min(10, int(fb.rating) * 2))
        ev = Evaluation(
            interview_id=inv.id,
            interviewer_id=interviewer.id,
            technical_score=overall,
            communication_score=overall,
            overall_score=overall,
            result="Pending",
            feedback=fb.comments,
            created_at=fb.created_at or datetime.utcnow(),
        )
        db.session.add(ev)
        inv.status = "Completed"
    db.session.commit()
