"""Capture HR app screens by domain/entity and build a PowerPoint deck."""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation
from pptx.util import Inches, Pt
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

BASE = "http://127.0.0.1:5000"
SHOT_DIR = ROOT / "presentation_screenshots"
OUT_PPT = ROOT / "HR_Recruitment_Domains_and_Entities.pptx"

# (filename, url, title, domain, entities, needs_login_role or None)
CAPTURES: list[tuple[str, str, str, str, str, str | None]] = [
    ("01_login.png", f"{BASE}/login", "Login", "Authentication", "User (all roles)", None),
    (
        "02_jobs_list.png",
        f"{BASE}/jobs",
        "Open positions",
        "Public jobs",
        "JobOpening",
        None,
    ),
    (
        "03_job_detail.png",
        f"{BASE}/jobs/HR-JOB-0001",
        "Job posting detail",
        "Public jobs",
        "JobOpening",
        None,
    ),
    (
        "04_job_apply.png",
        f"{BASE}/jobs/HR-JOB-0001/apply",
        "Apply for job",
        "Public jobs",
        "JobApplication",
        None,
    ),
    (
        "05_admin_dashboard.png",
        f"{BASE}/admin/dashboard",
        "Admin dashboard",
        "Admin",
        "User, Candidate, Interviewer, Interview, Evaluation (counts)",
        "admin",
    ),
    (
        "06_admin_pipeline.png",
        f"{BASE}/admin/pipeline",
        "Hiring pipeline",
        "Admin",
        "Candidate, Interview, Evaluation",
        "admin",
    ),
    (
        "07_admin_recruiters.png",
        f"{BASE}/admin/recruiters",
        "Recruiters",
        "Admin",
        "User (recruiter role)",
        "admin",
    ),
    (
        "08_admin_interviewers.png",
        f"{BASE}/admin/interviewers",
        "Interviewers",
        "Admin",
        "Interviewer, User",
        "admin",
    ),
    (
        "09_admin_candidates.png",
        f"{BASE}/admin/candidates",
        "Candidates",
        "Admin",
        "Candidate, User",
        "admin",
    ),
    (
        "10_admin_add_candidate.png",
        f"{BASE}/admin/candidates/add",
        "Add candidate",
        "Admin",
        "Candidate",
        "admin",
    ),
    (
        "11_admin_jobs.png",
        f"{BASE}/admin/jobs",
        "Manage job postings",
        "Admin",
        "JobOpening",
        "admin",
    ),
    (
        "12_admin_applications.png",
        f"{BASE}/admin/applications",
        "Job applications",
        "Admin",
        "JobApplication, JobOpening",
        "admin",
    ),
    (
        "13_admin_schedule.png",
        f"{BASE}/admin/candidates/1/schedule",
        "Schedule interview",
        "Admin",
        "Interview, Interviewer, Candidate",
        "admin",
    ),
    (
        "14_admin_feedback.png",
        f"{BASE}/admin/candidates/1/feedback",
        "Evaluation / feedback",
        "Admin",
        "Evaluation, Interview, Feedback (legacy)",
        "admin",
    ),
    (
        "15_recruiter_dashboard.png",
        f"{BASE}/recruiter/dashboard",
        "Recruiter dashboard",
        "Recruiter",
        "Candidate (assigned)",
        "recruiter",
    ),
    (
        "16_interviewer_dashboard.png",
        f"{BASE}/interviewer/dashboard",
        "Interviewer dashboard",
        "Interviewer",
        "Interview, Candidate",
        "interviewer",
    ),
    (
        "17_interviewer_evaluate.png",
        f"{BASE}/interviewer/interview/1/evaluate",
        "Submit evaluation",
        "Interviewer",
        "Evaluation, Interview",
        "interviewer",
    ),
    (
        "18_candidate_dashboard.png",
        f"{BASE}/candidate/dashboard",
        "Candidate dashboard",
        "Candidate",
        "Candidate, Interview",
        "candidate",
    ),
    (
        "19_candidate_result.png",
        f"{BASE}/candidate/result",
        "Candidate result",
        "Candidate",
        "Candidate (status outcome)",
        "candidate",
    ),
]

ROLE_USERS = {
    "admin": ("admin", "admin123"),
    "recruiter": ("Arya Hanamghar", None),
    "interviewer": ("priya", None),
    "candidate": ("tanugurav", None),
}


def make_driver() -> webdriver.Chrome:
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1440,900")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--hide-scrollbars")
    return webdriver.Chrome(options=opts)


def logout(driver: webdriver.Chrome) -> None:
    driver.get(f"{BASE}/logout")
    time.sleep(0.4)


def login(driver: webdriver.Chrome, role: str, username: str, password: str) -> None:
    driver.get(f"{BASE}/login")
    wait = WebDriverWait(driver, 15)
    wait.until(EC.presence_of_element_located((By.NAME, "username")))
    Select(driver.find_element(By.NAME, "role")).select_by_value(role)
    driver.find_element(By.NAME, "username").clear()
    driver.find_element(By.NAME, "username").send_keys(username)
    driver.find_element(By.NAME, "password").clear()
    driver.find_element(By.NAME, "password").send_keys(password)
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    wait.until(lambda d: "/login" not in d.current_url)


def capture_page(driver: webdriver.Chrome, path: Path) -> None:
    time.sleep(0.6)
    # Full page height
    total_height = driver.execute_script(
        "return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);"
    )
    driver.set_window_size(1440, min(max(total_height + 80, 900), 8000))
    time.sleep(0.3)
    path.parent.mkdir(parents=True, exist_ok=True)
    driver.save_screenshot(str(path))


def build_ppt(slides_meta: list[tuple[str, str, str, str, Path]]) -> None:
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Title
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    title_box = slide.shapes.add_textbox(Inches(0.6), Inches(2.2), Inches(12), Inches(1.2))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "HR Recruitment System"
    p.font.size = Pt(44)
    p.font.bold = True
    sub = tf.add_paragraph()
    sub.text = "Application domains & data entities (screens from http://127.0.0.1:5000)"
    sub.font.size = Pt(20)

    # Domains overview
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    box = slide.shapes.add_textbox(Inches(0.6), Inches(0.5), Inches(12), Inches(6.5))
    tf = box.text_frame
    tf.word_wrap = True
    lines = [
        "Application domains (Flask blueprints)",
        "",
        "• Authentication — /login, /logout",
        "• Public jobs — /jobs, job detail, apply (JobOpening, JobApplication)",
        "• Admin — dashboard, pipeline, recruiters, interviewers, candidates, jobs, applications",
        "• Recruiter — assigned candidates",
        "• Interviewer — interviews and Evaluation",
        "• Candidate — profile, interviews, final result",
        "",
        "Core entities: User, Candidate, JobOpening, JobApplication, Interviewer,",
        "Interview, Evaluation (+ legacy Feedback table)",
    ]
    for i, line in enumerate(lines):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.text = line
        para.font.size = Pt(22 if i == 0 else 18)
        if i == 0:
            para.font.bold = True

    blank = prs.slide_layouts[6]
    for title, domain, entities, img_path in slides_meta:
        if not img_path.is_file():
            continue
        slide = prs.slides.add_slide(blank)
        header = slide.shapes.add_textbox(Inches(0.4), Inches(0.2), Inches(12.5), Inches(0.9))
        ht = header.text_frame.paragraphs[0]
        ht.text = f"{title}  |  Domain: {domain}"
        ht.font.size = Pt(22)
        ht.font.bold = True
        sub = header.text_frame.add_paragraph()
        sub.text = f"Entities: {entities}"
        sub.font.size = Pt(14)

        slide.shapes.add_picture(str(img_path), Inches(0.4), Inches(1.1), width=Inches(12.5))

    prs.save(str(OUT_PPT))


def main() -> None:
    from app import app
    from extensions import db
    from models import User

    demo_pwd = "ppt-screenshot-demo"
    with app.app_context():
        for role, (user, pwd) in list(ROLE_USERS.items()):
            if pwd:
                continue
            u = User.query.filter_by(username=user, role=role).first()
            if not u:
                continue
            for trial in (demo_pwd, "password123", "candidate123", "recruiter123", "interviewer123", user):
                if u.check_password(trial):
                    ROLE_USERS[role] = (user, trial)
                    break
            else:
                u.set_password(demo_pwd)
                db.session.commit()
                ROLE_USERS[role] = (user, demo_pwd)
                print(f"Set temporary password for {role} user '{user}' (local demo only)")

    driver = make_driver()
    slides_meta: list[tuple[str, str, str, str, Path]] = []
    current_role: str | None = None

    try:
        for fname, url, title, domain, entities, login_role in CAPTURES:
            out = SHOT_DIR / fname
            if login_role:
                user, pwd = ROLE_USERS.get(login_role, (None, None))
                if not user or not pwd:
                    print(f"SKIP {fname}: no credentials for role {login_role}")
                    continue
                if current_role != login_role:
                    logout(driver)
                    login(driver, login_role, user, pwd)
                    current_role = login_role
            else:
                if current_role:
                    logout(driver)
                    current_role = None

            driver.get(url)
            try:
                capture_page(driver, out)
                slides_meta.append((title, domain, entities, out))
                print(f"OK {fname}")
            except Exception as exc:
                print(f"FAIL {fname}: {exc}")
    finally:
        driver.quit()

    build_ppt(slides_meta)
    print(f"Saved {OUT_PPT} ({len(slides_meta)} screenshot slides)")


if __name__ == "__main__":
    main()
