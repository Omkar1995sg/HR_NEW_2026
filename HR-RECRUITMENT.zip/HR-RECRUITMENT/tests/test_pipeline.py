import unittest
from types import SimpleNamespace

from pipeline import pipeline_stage, suggested_candidate_status


def _candidate(status="pending", interviews=None):
    return SimpleNamespace(status=status, interviews=interviews or [])


class PipelineStageTests(unittest.TestCase):
    def test_intake_when_no_interviews(self):
        self.assertEqual(pipeline_stage(_candidate()), "intake")

    def test_interview_when_no_evaluation(self):
        inv = SimpleNamespace(status="Scheduled", evaluation=None)
        self.assertEqual(pipeline_stage(_candidate(interviews=[inv])), "interview")

    def test_awaiting_decision_does_not_change_official_status(self):
        ev = SimpleNamespace(result="Selected", created_at=None, id=1)
        inv = SimpleNamespace(status="Completed", evaluation=ev)
        c = _candidate(interviews=[inv])
        self.assertEqual(pipeline_stage(c), "awaiting_decision")
        self.assertEqual(suggested_candidate_status(c), "selected")

    def test_official_selected_is_hired(self):
        ev = SimpleNamespace(result="Selected", created_at=None, id=1)
        inv = SimpleNamespace(status="Completed", evaluation=ev)
        c = _candidate(status="selected", interviews=[inv])
        self.assertEqual(pipeline_stage(c), "hired")

    def test_hold_stays_awaiting_decision_without_suggested_status(self):
        ev = SimpleNamespace(result="Hold", created_at=None, id=1)
        inv = SimpleNamespace(status="Completed", evaluation=ev)
        c = _candidate(interviews=[inv])
        self.assertEqual(pipeline_stage(c), "awaiting_decision")
        self.assertIsNone(suggested_candidate_status(c))


if __name__ == "__main__":
    unittest.main()
